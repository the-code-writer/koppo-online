import { StrategyList2 } from "../components/StrategyList2";

const DiscoverPage = () => {
  return <StrategyList2 />;
};

export default DiscoverPage;
