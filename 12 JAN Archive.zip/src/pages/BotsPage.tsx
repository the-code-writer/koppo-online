import { Bots2 } from "../components/Bots2";

const BotsPage = () => {
  return <Bots2 />;
};

export default BotsPage;
