import { StrategyList } from "../components/StrategyList";

const DiscoverPage = () => {
  return <StrategyList />;
};

export default DiscoverPage;
