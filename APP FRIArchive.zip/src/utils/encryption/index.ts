// Browser-compatible encryption using Web Crypto API
export { Encryption } from './browser';

// Re-export types for compatibility
export * from './types';
