/**
 * @file: Header/index.tsx
 * @description: Application header component that displays authentication state,
 *               account information, and provides login/deposit functionality.
 *
 * @components: Header - Main header component with conditional rendering based on auth state
 * @dependencies:
 *   - antd: Button, Space, Dropdown components
 *   - assets/logo.png: Logo image
 *   - styles.scss: Component styling
 * @usage:
 *   <Header
 *     isLoggedIn={true}
 *     accountType="Real"
 *     balance="1000.00"
 *     currency="USD"
 *     onDepositClick={() => {}}
 *   />
 *
 * @architecture: Presentational component with conditional rendering
 * @relationships:
 *   - Used by: App.tsx
 *   - Related to: AccountHeader component
 * @dataFlow: Receives auth state and account data as props, triggers login/deposit actions
 *
 * @ai-hints: This component uses conditional rendering based on isLoggedIn prop
 *            to display different UI states. The component is purely presentational
 *            and doesn't manage its own state.
 */
import { Button, Space, Dropdown, Avatar, Flex } from "antd";
import type { MenuProps } from "antd";
import { UserOutlined, SettingOutlined, LogoutOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import DerivLogo from "../../assets/logo.png";
import "./styles.scss";
import { useEffect, useState, useCallback } from "react";
import { User } from "../../services/api";

// Selected Deriv Account Component
const SelectedDerivAccount = ({ account }: { account: any }) => {
  const getCurrencyIcon = (currency: string) => {
    const currencyIcons: { [key: string]: string } = {
      'USD': '$',
      'USDC': '$',
      'BTC': '₿',
      'ETH': 'Ξ',
      'LTC': 'Ł',
      'XRP': 'X',
      'eUSDT': '₮',
      'tUSDT': '₮',
    };
    return currencyIcons[currency] || currency;
  };

  if (!account) return null;

  return (
    <div style={{ textAlign: "right" }}>
      <span className="app-header__username"><strong>{account?.account || ''}</strong><br />
        <sup>{getCurrencyIcon(account.currency)} {account.currency} • {account.balance.toFixed(2)}</sup></span>
    </div>
  );
};

interface Account {
  account: string;
  token: string;
  currency: string;
  balance: any;
}

interface HeaderProps {
  isLoggedIn?: boolean;
  user?: User | null;
  onLogin?: () => void;
  onLogout?: () => void;
  onDepositClick?: () => void;
  onSelectedAccount?: (account: Account) => void;
}

export function Header({
  isLoggedIn = false,
  user,
  onLogin,
  onLogout,
  onDepositClick,
  onSelectedAccount,
}: HeaderProps) {
  const navigate = useNavigate();

  const [selectedDerivAccount, setSelectedDerivAccount] = useState({
    account: "VTS04457001",
    currency: "USD",
    token: "abc123",
    balance: 1556.58
  });

  // User profile dropdown menu items
  const userProfileMenuItems: MenuProps["items"] = [
    {
      key: 'menu',
      label: (
        <div onClick={() => navigate('/menu')}>
          <SettingOutlined /> Menu
        </div>
      ),
    },
    {
      key: 'logout',
      label: (
        <div onClick={onLogout}>
          <LogoutOutlined /> Logout
        </div>
      ),
    },
  ];

  return (
    <header className="app-header">
      {!isLoggedIn ? (
        // Not logged in - show logo and login button
        <>
          <div className="app-header__logo-section">
            <img
              src={DerivLogo}
              alt="Deriv Logo"
              className="app-header__logo"
            />
          </div>
          <Space>
            {onLogin && (
              <Button
                type="default"
                onClick={onLogin}
                className="app-header__deposit-btn"
              >
                Log in
              </Button>
            )}
          </Space>
        </>
      ) : (
        // Logged in - show account info and actions
        <>
          <div className="app-header__user-section">
            <div className="app-header__logo-section">
              <img
                src={DerivLogo}
                alt="Deriv Logo"
                className="app-header__logo"
              />
            </div>
          </div>

          {/* User profile dropdown when authenticated */}<Space>
            {isLoggedIn && user && (
              <Dropdown
                menu={{ items: userProfileMenuItems }}
                placement="bottomRight"
                trigger={["click"]}
              >
                <Flex justify="align-center" align="center" gap={8}>

                  {/* Selected Deriv Account */}
                  {selectedDerivAccount && (
                    <SelectedDerivAccount account={selectedDerivAccount} />
                  )}<Avatar
                    src={user.accounts?.firebase?.photoURL || undefined}
                    icon={<UserOutlined />} size={40}
                  />

                </Flex>
              </Dropdown>
            )}
          </Space>
        </>
      )}
    </header>
  );
}
