import { useState } from "react";
import { Modal, Form, Input, Button, Avatar, Upload, Divider, Space, Typography, Alert, Switch } from "antd";
import { UserOutlined, CameraOutlined, LinkOutlined, KeyOutlined, GoogleOutlined, MessageOutlined } from "@ant-design/icons";
import { User } from "../../services/api";
import "./styles.scss";

const { Title, Text } = Typography;

interface ProfileSettingsModalProps {
  visible: boolean;
  onClose: () => void;
  user: User | null;
}

export function ProfileSettingsModal({ visible, onClose, user }: ProfileSettingsModalProps) {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [telegramLinked, setTelegramLinked] = useState(false);
  const [googleLinked, setGoogleLinked] = useState(false);
  const [derivLinked, setDerivLinked] = useState(false);

  // Initialize form with user data
  useState(() => {
    if (user) {
      form.setFieldsValue({
        firstName: user.firstName,
        lastName: user.lastName,
        displayName: user.displayName,
        username: user.username,
        email: user.email,
        phoneNumber: user.phoneNumber
      });
    }
  });

  const handleProfileImageUpload = (info: any) => {
    if (info.file.status === 'done') {
      // Get the base64 or URL of the uploaded image
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(info.file.originFileObj);
    }
  };

  const handleUpdateProfile = async (values: any) => {
    setLoading(true);
    try {
      // TODO: Implement API call to update profile
      console.log('Updating profile:', values);
      // await authAPI.updateProfile(values);
      
      // Show success message
      Modal.success({
        title: 'Profile Updated',
        content: 'Your profile has been successfully updated.',
      });
      
      onClose();
    } catch (error) {
      console.error('Error updating profile:', error);
      Modal.error({
        title: 'Update Failed',
        content: 'Failed to update profile. Please try again.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRevokeTokens = () => {
    Modal.confirm({
      title: 'Revoke All Tokens',
      content: 'Are you sure you want to revoke all active tokens? You will need to log in again on all devices.',
      okText: 'Revoke',
      okType: 'danger',
      onOk: async () => {
        try {
          // TODO: Implement API call to revoke tokens
          console.log('Revoking tokens');
          // await authAPI.revokeTokens();
          
          Modal.success({
            title: 'Tokens Revoked',
            content: 'All tokens have been successfully revoked.',
          });
        } catch (error) {
          console.error('Error revoking tokens:', error);
          Modal.error({
            title: 'Revoke Failed',
            content: 'Failed to revoke tokens. Please try again.',
          });
        }
      },
    });
  };

  const handleLinkTelegram = () => {
    // TODO: Implement Telegram OAuth flow
    console.log('Linking Telegram account');
  };

  const handleLinkGoogle = () => {
    // TODO: Implement Google OAuth flow
    console.log('Linking Google account');
  };

  const handleLinkDeriv = () => {
    // TODO: Implement Deriv OAuth flow
    console.log('Linking Deriv account');
  };

  const uploadButton = (
    <div>
      <CameraOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );

  return (
    <Modal
      title="Profile Settings"
      open={visible}
      onCancel={onClose}
      footer={null}
      width={600}
      className="profile-settings-modal"
    >
      <div className="profile-settings-content">
        {/* Profile Picture Section */}
        <div className="profile-picture-section">
          <div className="profile-picture-upload">
            <Upload
              name="avatar"
              listType="picture-card"
              className="avatar-uploader"
              showUploadList={false}
              beforeUpload={() => false} // Prevent automatic upload
              onChange={handleProfileImageUpload}
            >
              {profileImage ? (
                <Avatar src={profileImage} size={80} />
              ) : (
                <Avatar icon={<UserOutlined />} size={80} />
              )}
            </Upload>
            <Title level={5}>Profile Picture</Title>
            <Text type="secondary">Upload a new profile picture</Text>
          </div>
        </div>

        <Divider />

        {/* Profile Information Form */}
        <Form
          form={form}
          layout="vertical"
          onFinish={handleUpdateProfile}
          className="profile-form"
        >
          <Form.Item
            label="First Name"
            name="firstName"
            rules={[{ required: true, message: 'Please enter your first name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Last Name"
            name="lastName"
            rules={[{ required: true, message: 'Please enter your last name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Display Name"
            name="displayName"
            rules={[{ required: true, message: 'Please enter your display name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Username"
            name="username"
            rules={[{ required: true, message: 'Please enter your username' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Email"
            name="email"
            rules={[
              { required: true, message: 'Please enter your email' },
              { type: 'email', message: 'Please enter a valid email' }
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Phone Number"
            name="phoneNumber"
            rules={[{ required: true, message: 'Please enter your phone number' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" loading={loading}>
                Update Profile
              </Button>
              <Button onClick={onClose}>
                Cancel
              </Button>
            </Space>
          </Form.Item>
        </Form>

        <Divider />

        {/* Security Section */}
        <div className="security-section">
          <Title level={5}>Security</Title>
          
          <div className="security-item">
            <div className="security-item-content">
              <KeyOutlined />
              <div>
                <Text strong>Revoke Tokens</Text>
                <br />
                <Text type="secondary">Revoke all active session tokens</Text>
              </div>
            </div>
            <Button danger onClick={handleRevokeTokens}>
              Revoke
            </Button>
          </div>
        </div>

        <Divider />

        {/* Linked Accounts Section */}
        <div className="linked-accounts-section">
          <Title level={5}>Linked Accounts</Title>
          
          <div className="linked-account-item">
            <div className="linked-account-content">
              <MessageOutlined />
              <div>
                <Text strong>Telegram</Text>
                <br />
                <Text type="secondary">
                  {telegramLinked ? 'Account linked' : 'Link your Telegram account'}
                </Text>
              </div>
            </div>
            <Switch
              checked={telegramLinked}
              onChange={handleLinkTelegram}
            />
          </div>

          <div className="linked-account-item">
            <div className="linked-account-content">
              <GoogleOutlined />
              <div>
                <Text strong>Google</Text>
                <br />
                <Text type="secondary">
                  {googleLinked ? 'Account linked' : 'Link your Google account'}
                </Text>
              </div>
            </div>
            <Switch
              checked={googleLinked}
              onChange={handleLinkGoogle}
            />
          </div>

          <div className="linked-account-item">
            <div className="linked-account-content">
              <LinkOutlined />
              <div>
                <Text strong>Deriv</Text>
                <br />
                <Text type="secondary">
                  {derivLinked ? 'Account linked' : 'Link your Deriv account'}
                </Text>
              </div>
            </div>
            <Switch
              checked={derivLinked}
              onChange={handleLinkDeriv}
            />
          </div>
        </div>
      </div>
    </Modal>
  );
}
