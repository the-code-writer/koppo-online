import { useState, useEffect } from "react";
import { Drawer, Form, Input, Button, Avatar, Upload, Divider, Space, Typography, Switch } from "antd";
import { UserOutlined, CameraOutlined, LinkOutlined, KeyOutlined, GoogleOutlined, MessageOutlined } from "@ant-design/icons";
import { User } from "../../services/api";
import "./styles.scss";

const { Title, Text } = Typography;

interface ProfileSettingsDrawerProps {
  visible: boolean;
  onClose: () => void;
  user: User | null;
}

export function ProfileSettingsDrawer({ visible, onClose, user }: ProfileSettingsDrawerProps) {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [telegramLinked, setTelegramLinked] = useState(false);
  const [googleLinked, setGoogleLinked] = useState(false);
  const [derivLinked, setDerivLinked] = useState(false);

  // Initialize form with user data
  useEffect(() => {
    if (user) {
      form.setFieldsValue({
        firstName: user.firstName,
        lastName: user.lastName,
        displayName: user.displayName,
        username: user.username,
        email: user.email,
        phoneNumber: user.phoneNumber
      });
    }
  }, [user, form]);

  const handleProfileImageUpload = (info: any) => {
    if (info.file.status === 'done') {
      // Get the base64 or URL of the uploaded image
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(info.file.originFileObj);
    }
  };

  const handleUpdateProfile = async (values: any) => {
    setLoading(true);
    try {
      // TODO: Implement API call to update profile
      console.log('Updating profile:', values);
      // await authAPI.updateProfile(values);
      
      // Show success message
      // You can use antd message here
      console.log('Profile updated successfully');
      
      onClose();
    } catch (error) {
      console.error('Error updating profile:', error);
      // Show error message
      console.error('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handleRevokeTokens = () => {
    // TODO: Implement token revocation
    console.log('Revoking tokens');
  };

  const handleLinkTelegram = (checked: boolean) => {
    setTelegramLinked(checked);
    // TODO: Implement Telegram OAuth flow
    console.log('Linking Telegram account:', checked);
  };

  const handleLinkGoogle = (checked: boolean) => {
    setGoogleLinked(checked);
    // TODO: Implement Google OAuth flow
    console.log('Linking Google account:', checked);
  };

  const handleLinkDeriv = (checked: boolean) => {
    setDerivLinked(checked);
    // TODO: Implement Deriv OAuth flow
    console.log('Linking Deriv account:', checked);
  };

  return (
    <Drawer
      title="Profile Settings"
      placement="right"
      onClose={onClose}
      open={visible}
      width={400}
      className="profile-settings-drawer"
    >
      <div className="profile-settings-content">
        {/* Profile Picture Section */}
        <div className="profile-picture-section">
          <div className="profile-picture-upload">
            <Upload
              name="avatar"
              listType="picture-card"
              className="avatar-uploader"
              showUploadList={false}
              beforeUpload={() => false} // Prevent automatic upload
              onChange={handleProfileImageUpload}
            >
              {profileImage ? (
                <Avatar src={profileImage} size={80} />
              ) : (
                <Avatar icon={<UserOutlined />} size={80} />
              )}
            </Upload>
            <Title level={5}>Profile Picture</Title>
            <Text type="secondary">Upload a new profile picture</Text>
          </div>
        </div>

        <Divider />

        {/* Profile Information Form */}
        <Form
          form={form}
          layout="vertical"
          onFinish={handleUpdateProfile}
          className="profile-form"
        >
          <Form.Item
            label="First Name"
            name="firstName"
            rules={[{ required: true, message: 'Please enter your first name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Last Name"
            name="lastName"
            rules={[{ required: true, message: 'Please enter your last name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Display Name"
            name="displayName"
            rules={[{ required: true, message: 'Please enter your display name' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Username"
            name="username"
            rules={[{ required: true, message: 'Please enter your username' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Email"
            name="email"
            rules={[
              { required: true, message: 'Please enter your email' },
              { type: 'email', message: 'Please enter a valid email' }
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Phone Number"
            name="phoneNumber"
            rules={[{ required: true, message: 'Please enter your phone number' }]}
          >
            <Input />
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" loading={loading}>
                Update Profile
              </Button>
              <Button onClick={onClose}>
                Cancel
              </Button>
            </Space>
          </Form.Item>
        </Form>

        <Divider />

        {/* Security Section */}
        <div className="security-section">
          <Title level={5}>Security</Title>
          
          <div className="security-item">
            <div className="security-item-content">
              <KeyOutlined />
              <div>
                <Text strong>Revoke Tokens</Text>
                <br />
                <Text type="secondary">Revoke all active session tokens</Text>
              </div>
            </div>
            <Button danger onClick={handleRevokeTokens}>
              Revoke
            </Button>
          </div>
        </div>

        <Divider />

        {/* Linked Accounts Section */}
        <div className="linked-accounts-section">
          <Title level={5}>Linked Accounts</Title>
          
          <div className="linked-account-item">
            <div className="linked-account-content">
              <MessageOutlined />
              <div>
                <Text strong>Telegram</Text>
                <br />
                <Text type="secondary">
                  {telegramLinked ? 'Account linked' : 'Link your Telegram account'}
                </Text>
              </div>
            </div>
            <Switch
              checked={telegramLinked}
              onChange={handleLinkTelegram}
            />
          </div>

          <div className="linked-account-item">
            <div className="linked-account-content">
              <GoogleOutlined />
              <div>
                <Text strong>Google</Text>
                <br />
                <Text type="secondary">
                  {googleLinked ? 'Account linked' : 'Link your Google account'}
                </Text>
              </div>
            </div>
            <Switch
              checked={googleLinked}
              onChange={handleLinkGoogle}
            />
          </div>

          <div className="linked-account-item">
            <div className="linked-account-content">
              <LinkOutlined />
              <div>
                <Text strong>Deriv</Text>
                <br />
                <Text type="secondary">
                  {derivLinked ? 'Account linked' : 'Link your Deriv account'}
                </Text>
              </div>
            </div>
            <Switch
              checked={derivLinked}
              onChange={handleLinkDeriv}
            />
          </div>
        </div>
      </div>
    </Drawer>
  );
}
