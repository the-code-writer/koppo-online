export { default as DiscoverPage } from './DiscoverPage';
export { default as BotsPage } from './BotsPage';
export { default as PositionsPage } from './PositionsPage';
export { default as SettingsPage } from './SettingsPage';
export { default as ConfigEndpointPage } from './ConfigEndpointPage';
